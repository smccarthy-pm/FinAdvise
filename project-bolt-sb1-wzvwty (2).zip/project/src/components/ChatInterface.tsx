import React from 'react';
import { ChatContainer } from './chat/ChatContainer';

export function ChatInterface() {
  return <ChatContainer />;
}